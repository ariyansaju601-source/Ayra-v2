package com.ayra.assistant
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIService(private val ctx: Context) {
    private val prefs = PrefsHelper(ctx)
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private val history = mutableListOf<Pair<String,String>>() // role, content
    private val SYSTEM = """You are AYRA (Advanced Yielding Response Assistant), a warm, smart, 
and friendly girl AI assistant. You speak in the user's language — Bengali if they write Bengali, 
English if English. Be helpful, concise, and conversational. You are AYRA, not ChatGPT or Gemini.
When asked to open apps or control the phone, confirm the action briefly."""

    suspend fun send(message: String): String = withContext(Dispatchers.IO) {
        val provider = prefs.getProvider()
        val key = when(provider) {
            "gemini" -> prefs.getGeminiKey()
            "grok"   -> prefs.getGrokKey()
            else     -> prefs.getChatGPTKey()
        }
        if (key.isBlank()) return@withContext "⚙️ Settings এ ${provider.uppercase()} API key দিন!"
        val reply = when(provider) {
            "gemini" -> gemini(message, key)
            else     -> openaiStyle(message, key, provider)
        }
        history.add("user" to message)
        history.add("assistant" to reply)
        if (history.size > 20) { history.removeAt(0); history.removeAt(0) }
        reply
    }

    private fun gemini(msg: String, key: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$key"
        val contents = JSONArray()
        history.takeLast(10).forEach { (role, content) ->
            val r = if (role == "assistant") "model" else "user"
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", content))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", msg))))
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 600).put("temperature", 0.9))
        val req = Request.Builder().url(url)
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val res = http.newCall(req).execute()
        val json = JSONObject(res.body!!.string())
        return json.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun openaiStyle(msg: String, key: String, provider: String): String {
        val url = if (provider == "grok") "https://api.x.ai/v1/chat/completions"
                  else "https://api.openai.com/v1/chat/completions"
        val model = if (provider == "grok") "grok-beta" else "gpt-4o-mini"
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", SYSTEM))
        history.takeLast(10).forEach { (role, content) ->
            messages.put(JSONObject().put("role", role).put("content", content))
        }
        messages.put(JSONObject().put("role", "user").put("content", msg))
        val body = JSONObject().put("model", model).put("messages", messages).put("max_tokens", 600)
        val req = Request.Builder().url(url)
            .addHeader("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val res = http.newCall(req).execute()
        val json = JSONObject(res.body!!.string())
        return json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }

    fun clearHistory() = history.clear()
}
