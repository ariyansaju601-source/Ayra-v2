package com.ayra.assistant
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class SettingsActivity : AppCompatActivity() {
    private val prefs by lazy { PrefsHelper(this) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val gemini   = findViewById<EditText>(R.id.input_gemini)
        val chatgpt  = findViewById<EditText>(R.id.input_chatgpt)
        val grok     = findViewById<EditText>(R.id.input_grok)
        val provider = findViewById<Spinner>(R.id.spinner_provider)
        val lang     = findViewById<Spinner>(R.id.spinner_language)
        val autoStart= findViewById<Switch>(R.id.switch_autostart)
        val save     = findViewById<Button>(R.id.btn_save)
        gemini.setText(prefs.getGeminiKey())
        chatgpt.setText(prefs.getChatGPTKey())
        grok.setText(prefs.getGrokKey())
        autoStart.isChecked = prefs.isAutoStart()
        val providers = arrayOf("gemini","chatgpt","grok")
        val pLabels = arrayOf("🤖 Gemini (Google - Free!)","💬 ChatGPT (OpenAI)","⚡ Grok (xAI)")
        provider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, pLabels)
        provider.setSelection(providers.indexOf(prefs.getProvider()).coerceAtLeast(0))
        val langCodes = arrayOf("bn-BD","bn-IN","en-US","en-GB","hi-IN","ar-SA","ur-PK","es-ES","fr-FR","zh-CN")
        val lLabels = arrayOf("বাংলা 🇧🇩","বাংলা 🇮🇳","English 🇺🇸","English 🇬🇧","हिन्दी 🇮🇳","العربية 🇸🇦","اردو 🇵🇰","Español 🇪🇸","Français 🇫🇷","中文 🇨🇳")
        lang.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, lLabels)
        lang.setSelection(langCodes.indexOf(prefs.getLanguage()).coerceAtLeast(0))
        save.setOnClickListener {
            prefs.setGeminiKey(gemini.text.toString().trim())
            prefs.setChatGPTKey(chatgpt.text.toString().trim())
            prefs.setGrokKey(grok.text.toString().trim())
            prefs.setProvider(providers[provider.selectedItemPosition])
            prefs.setLanguage(langCodes[lang.selectedItemPosition])
            prefs.setAutoStart(autoStart.isChecked)
            Toast.makeText(this, "✅ সেটিংস সেভ হয়েছে!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
