package com.ayra.assistant
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        val orb = findViewById<ImageView>(R.id.splash_orb)
        val name = findViewById<TextView>(R.id.splash_name)
        val sub = findViewById<TextView>(R.id.splash_sub)
        orb.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse))
        name.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        sub.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2800)
    }
}
