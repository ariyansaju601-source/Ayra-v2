package com.ayra.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var inputText: EditText
    private lateinit var chatLog: TextView
    private lateinit var chatScroll: ScrollView
    private lateinit var statusText: TextView
    private lateinit var micBtn: ImageButton
    private lateinit var sendBtn: ImageButton
    private lateinit var settingsBtn: ImageButton
    private lateinit var clearBtn: ImageButton
    private lateinit var orbView: ImageView
    private lateinit var waveView: ImageView

    private val prefs by lazy { PrefsHelper(this) }
    private val ai by lazy { AIService(this) }
    private val cmd by lazy { CommandHandler(this) }

    private var ttsReady = false
    private var micActive = false
    private val chatBuilder = SpannableStringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputText   = findViewById(R.id.input_text)
        chatLog     = findViewById(R.id.chat_log)
        chatScroll  = findViewById(R.id.chat_scroll)
        statusText  = findViewById(R.id.status_text)
        micBtn      = findViewById(R.id.btn_mic)
        sendBtn     = findViewById(R.id.btn_send)
        settingsBtn = findViewById(R.id.btn_settings)
        clearBtn    = findViewById(R.id.btn_clear)
        orbView     = findViewById(R.id.orb_view)
        waveView    = findViewById(R.id.wave_view)

        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        setupRecognizer()

        // Orb idle pulse animation
        orbView.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pulse))

        // Load chat history
        val saved = prefs.getChatHistory()
        if (saved.isNotEmpty()) {
            chatBuilder.append(saved)
            chatLog.text = chatBuilder
        }

        sendBtn.setOnClickListener {
            val t = inputText.text.toString().trim()
            if (t.isNotEmpty()) { processInput(t); inputText.setText("") }
        }
        micBtn.setOnClickListener { if (!micActive) startMic() else stopMic() }
        settingsBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        clearBtn.setOnClickListener {
            chatBuilder.clear()
            chatLog.text = ""
            prefs.clearHistory()
            ai.clearHistory()
            Toast.makeText(this, "Chat cleared", Toast.LENGTH_SHORT).show()
        }

        checkPermissions()

        Handler(Looper.getMainLooper()).postDelayed({
            val greet = "হ্যালো! আমি AYRA 🤖 আপনার AI সহকারী। আমি কীভাবে সাহায্য করতে পারি?"
            appendMsg("AYRA", greet, Color.parseColor("#B39DFF"))
            speak(greet)
        }, 600)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale("bn", "BD"))
            // Try female voice
            tts.voices?.filter { v ->
                v.name.contains("female", true) || v.name.contains("f-", true)
            }?.firstOrNull()?.let { tts.voice = it }
            tts.setSpeechRate(0.88f)
            tts.setPitch(1.1f)
            ttsReady = true
        }
    }

    private fun speak(text: String) {
        if (!ttsReady) return
        val clean = text.replace(Regex("[*#`]"), "").replace(Regex("\\[.*?\\]"), "")
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "ayra_${System.currentTimeMillis()}")
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) {
                runOnUiThread {
                    orbView.clearAnimation()
                    orbView.startAnimation(AnimationUtils.loadAnimation(this@MainActivity, R.anim.speak_pulse))
                    waveView.visibility = android.view.View.VISIBLE
                }
            }
            override fun onDone(u: String?) {
                runOnUiThread {
                    orbView.clearAnimation()
                    orbView.startAnimation(AnimationUtils.loadAnimation(this@MainActivity, R.anim.pulse))
                    waveView.visibility = android.view.View.INVISIBLE
                }
            }
            @Deprecated("Deprecated")
            override fun onError(u: String?) { onDone(u) }
        })
    }

    private fun setupRecognizer() {
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {
                statusText.text = "🎙 শুনছি..."
                waveView.visibility = android.view.View.VISIBLE
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(r: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {
                statusText.text = "💭 চিন্তা করছি..."
                waveView.visibility = android.view.View.INVISIBLE
            }
            override fun onError(e: Int) {
                micActive = false
                statusText.text = "✨ প্রস্তুত"
                waveView.visibility = android.view.View.INVISIBLE
            }
            override fun onResults(r: Bundle?) {
                val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                micActive = false
                statusText.text = "✨ প্রস্তুত"
                processInput(text)
            }
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(e: Int, p: Bundle?) {}
        })
    }

    private fun startMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission দরকার", Toast.LENGTH_SHORT).show()
            return
        }
        micActive = true
        micBtn.setColorFilter(Color.parseColor("#FF6B9D"))
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.getLanguage())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
    }

    private fun stopMic() {
        micActive = false
        micBtn.clearColorFilter()
        recognizer.stopListening()
        statusText.text = "✨ প্রস্তুত"
    }

    private fun processInput(input: String) {
        appendMsg("আপনি", input, Color.parseColor("#7C4DFF"))
        val (handled, reply) = cmd.handle(input)
        if (handled) {
            if (reply.isNotEmpty()) {
                appendMsg("AYRA", reply, Color.parseColor("#B39DFF"))
                speak(reply)
            }
            statusText.text = "✨ প্রস্তুত"
            return
        }
        statusText.text = "💭 চিন্তা করছি..."
        lifecycleScope.launch {
            try {
                val response = ai.send(input)
                appendMsg("AYRA", response, Color.parseColor("#B39DFF"))
                speak(response)
                statusText.text = "✨ প্রস্তুত"
            } catch (e: Exception) {
                val err = "❌ সমস্যা হয়েছে: ${e.message}"
                appendMsg("AYRA", err, Color.parseColor("#FF6B6B"))
                statusText.text = "⚠️ ত্রুটি"
            }
        }
    }

    private fun appendMsg(from: String, text: String, color: Int) {
        val fromColor = if (from == "AYRA") Color.parseColor("#9B59FF") else Color.parseColor("#4FC3F7")
        val start = chatBuilder.length
        chatBuilder.append("\n$from\n")
        chatBuilder.setSpan(ForegroundColorSpan(fromColor), start + 1, start + 1 + from.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        val msgStart = chatBuilder.length
        chatBuilder.append("$text\n")
        chatBuilder.setSpan(ForegroundColorSpan(color), msgStart, chatBuilder.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        runOnUiThread {
            chatLog.text = chatBuilder
            chatScroll.post { chatScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
        // Save history (last 2000 chars)
        val full = chatBuilder.toString()
        prefs.setChatHistory(if (full.length > 2000) full.takeLast(2000) else full)
    }

    private fun checkPermissions() {
        val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::tts.isInitialized) tts.shutdown()
        if (::recognizer.isInitialized) recognizer.destroy()
    }
}
