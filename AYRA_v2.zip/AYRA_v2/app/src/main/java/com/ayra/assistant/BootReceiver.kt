package com.ayra.assistant
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && PrefsHelper(ctx).isAutoStart()) {
            ctx.startForegroundService(Intent(ctx, FloatingService::class.java))
        }
    }
}
