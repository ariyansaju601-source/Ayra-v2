package com.ayra.assistant
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.widget.Toast
import java.io.DataOutputStream
import java.util.Calendar

class CommandHandler(private val ctx: Context) {

    private val apps = mapOf(
        "whatsapp" to "com.whatsapp", "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "facebook" to "com.facebook.katana", "ফেসবুক" to "com.facebook.katana",
        "youtube" to "com.google.android.youtube", "ইউটিউব" to "com.google.android.youtube",
        "instagram" to "com.instagram.android", "ইনস্টাগ্রাম" to "com.instagram.android",
        "telegram" to "org.telegram.messenger", "টেলিগ্রাম" to "org.telegram.messenger",
        "gmail" to "com.google.android.gm",
        "chrome" to "com.android.chrome",
        "camera" to "com.android.camera2", "ক্যামেরা" to "com.android.camera2",
        "settings" to "com.android.settings", "সেটিংস" to "com.android.settings",
        "maps" to "com.google.android.apps.maps", "ম্যাপ" to "com.google.android.apps.maps",
        "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient",
        "tiktok" to "com.zhiliaoapp.musically",
        "calculator" to "com.android.calculator2", "ক্যালকুলেটর" to "com.android.calculator2",
        "clock" to "com.android.deskclock", "ঘড়ি" to "com.android.deskclock",
        "snapchat" to "com.snapchat.android",
        "twitter" to "com.twitter.android",
        "play store" to "com.android.vending",
        "photos" to "com.google.android.apps.photos",
        "files" to "com.google.android.apps.nbu.files"
    )

    // Returns Pair(handled, responseText)
    fun handle(input: String): Pair<Boolean, String> {
        val low = input.lowercase().trim()

        // ── OPEN APP ─────────────────────────────────────────────
        val openWords = listOf("open ", "খোলো ", "খোল ", "চালু করো ", "start ", "launch ")
        for (w in openWords) {
            if (low.startsWith(w)) {
                val name = low.removePrefix(w).trim()
                return openApp(name)
            }
        }

        // ── CALL ─────────────────────────────────────────────────
        if (low.startsWith("call ") || low.startsWith("কল করো ") || low.startsWith("ফোন করো ")) {
            val name = low.replace(Regex("(call |কল করো |ফোন করো )"), "").trim()
            return makeCall(name)
        }

        // ── SMS ──────────────────────────────────────────────────
        if (low.contains("sms") || low.contains("message করো") || low.contains("মেসেজ করো")) {
            return Pair(true, "কাকে মেসেজ করবো এবং কী লিখবো?")
        }

        // ── ALARM ────────────────────────────────────────────────
        if (low.contains("alarm") || low.contains("অ্যালার্ম")) {
            return setAlarm(low)
        }

        // ── FLASHLIGHT ───────────────────────────────────────────
        if (low.contains("টর্চ চালু") || low.contains("flashlight on") || low.contains("torch on")) {
            flashlight(true)
            return Pair(true, "টর্চ চালু করা হয়েছে! 🔦")
        }
        if (low.contains("টর্চ বন্ধ") || low.contains("flashlight off") || low.contains("torch off")) {
            flashlight(false)
            return Pair(true, "টর্চ বন্ধ করা হয়েছে!")
        }

        // ── VOLUME ───────────────────────────────────────────────
        if (low.contains("volume up") || low.contains("ভলিউম বাড়াও")) {
            root("input keyevent 24"); return Pair(true, "ভলিউম বাড়ানো হয়েছে 🔊")
        }
        if (low.contains("volume down") || low.contains("ভলিউম কমাও")) {
            root("input keyevent 25"); return Pair(true, "ভলিউম কমানো হয়েছে 🔇")
        }

        // ── SCREENSHOT ───────────────────────────────────────────
        if (low.contains("screenshot") || low.contains("স্ক্রিনশট")) {
            root("input keyevent 120"); return Pair(true, "স্ক্রিনশট নেওয়া হয়েছে! 📸")
        }

        // ── WEATHER ──────────────────────────────────────────────
        if (low.contains("weather") || low.contains("আবহাওয়া")) {
            openUrl("https://www.google.com/search?q=weather+today")
            return Pair(true, "আবহাওয়া দেখছি... 🌤️")
        }

        // ── YOUTUBE SEARCH ───────────────────────────────────────
        if (low.startsWith("youtube search") || low.startsWith("ইউটিউবে খোঁজো")) {
            val q = low.replace(Regex("(youtube search|ইউটিউবে খোঁজো)"), "").trim()
            openUrl("https://www.youtube.com/results?search_query=${Uri.encode(q)}")
            return Pair(true, "YouTube-এ \"$q\" খুঁজছি...")
        }

        // ── GOOGLE SEARCH ────────────────────────────────────────
        if (low.startsWith("search ") || low.startsWith("গুগলে খোঁজো ")) {
            val q = low.replace(Regex("(search |গুগলে খোঁজো )"), "").trim()
            openUrl("https://www.google.com/search?q=${Uri.encode(q)}")
            return Pair(true, "\"$q\" গুগলে খুঁজছি...")
        }

        // ── HOME / BACK ──────────────────────────────────────────
        if (low == "home" || low == "হোম") { root("input keyevent 3"); return Pair(true, "Home screen এ গেলাম!") }
        if (low == "back" || low == "পিছনে") { root("input keyevent 4"); return Pair(true, "পিছনে গেলাম!") }

        // ── BRIGHTNESS ───────────────────────────────────────────
        if (low.contains("brightness max") || low.contains("উজ্জ্বলতা বাড়াও")) {
            root("settings put system screen_brightness 255"); return Pair(true, "Brightness সর্বোচ্চ করা হয়েছে ☀️")
        }
        if (low.contains("brightness min") || low.contains("উজ্জ্বলতা কমাও")) {
            root("settings put system screen_brightness 10"); return Pair(true, "Brightness কমানো হয়েছে 🌑")
        }

        return Pair(false, "")
    }

    private fun openApp(name: String): Pair<Boolean, String> {
        val pkg = apps.entries.find { name.contains(it.key, true) }?.value
            ?: ctx.packageManager.getInstalledApplications(0)
                .find { ctx.packageManager.getApplicationLabel(it).toString().lowercase().contains(name) }?.packageName
            ?: return Pair(false, "")
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            Pair(true, "\"$name\" খোলা হচ্ছে... ✅")
        } else {
            root("monkey -p $pkg 1")
            Pair(true, "\"$name\" খোলার চেষ্টা করছি...")
        }
    }

    private fun makeCall(name: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$name"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            Pair(true, "$name-কে কল করা হচ্ছে... 📞")
        } catch (e: Exception) {
            Pair(true, "কল করতে পারিনি: ${e.message}")
        }
    }

    private fun setAlarm(input: String): Pair<Boolean, String> {
        return try {
            val hourMatch = Regex("(\\d{1,2})").find(input)
            val hour = hourMatch?.value?.toInt() ?: 7
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, 0)
                putExtra(AlarmClock.EXTRA_MESSAGE, "AYRA Alarm")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            Pair(true, "⏰ $hour:00 টায় অ্যালার্ম সেট করা হয়েছে!")
        } catch (e: Exception) {
            Pair(true, "অ্যালার্ম সেট করতে পারিনি।")
        }
    }

    private fun flashlight(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on)
        } catch (e: Exception) {
            toast("টর্চ কাজ করেনি")
        }
    }

    private fun openUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
    }

    private fun root(cmd: String) {
        try {
            val p = Runtime.getRuntime().exec("su")
            DataOutputStream(p.outputStream).apply { writeBytes("$cmd\nexit\n"); flush() }
            p.waitFor()
        } catch (_: Exception) {}
    }

    private fun toast(msg: String) = android.os.Handler(android.os.Looper.getMainLooper()).post {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }
}
