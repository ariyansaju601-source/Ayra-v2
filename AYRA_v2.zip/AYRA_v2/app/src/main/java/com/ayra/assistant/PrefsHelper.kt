package com.ayra.assistant
import android.content.Context
class PrefsHelper(ctx: Context) {
    private val p = ctx.getSharedPreferences("ayra_prefs", Context.MODE_PRIVATE)
    fun getGeminiKey() = p.getString("gemini_key", "") ?: ""
    fun setGeminiKey(v: String) = p.edit().putString("gemini_key", v).apply()
    fun getChatGPTKey() = p.getString("chatgpt_key", "") ?: ""
    fun setChatGPTKey(v: String) = p.edit().putString("chatgpt_key", v).apply()
    fun getGrokKey() = p.getString("grok_key", "") ?: ""
    fun setGrokKey(v: String) = p.edit().putString("grok_key", v).apply()
    fun getProvider() = p.getString("provider", "gemini") ?: "gemini"
    fun setProvider(v: String) = p.edit().putString("provider", v).apply()
    fun getLanguage() = p.getString("language", "bn-BD") ?: "bn-BD"
    fun setLanguage(v: String) = p.edit().putString("language", v).apply()
    fun isAutoStart() = p.getBoolean("auto_start", false)
    fun setAutoStart(v: Boolean) = p.edit().putBoolean("auto_start", v).apply()
    fun getChatHistory() = p.getString("chat_history", "") ?: ""
    fun setChatHistory(v: String) = p.edit().putString("chat_history", v).apply()
    fun clearHistory() = p.edit().remove("chat_history").apply()
}
